# Getting Started with EEGLAB

1. [Install EEGLAB](instructions/installing_eeglab.pdf)
2. Add raw **.csv** files to `raw/` directory
3. Open MATLAB
4. Run the following command in MATLAB `run preprocess.m`  
  * This should generate processed files in the `clean` directory.
5. 